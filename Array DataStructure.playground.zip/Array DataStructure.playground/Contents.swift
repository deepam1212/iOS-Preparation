import UIKit

// Array Problems

//Move all the negative elements to one side of the array

func moveNegativeElementToOneSide() {
    var arr = [0, -1, 2, -3, 2, 1, 0, 2]
    
    for (index, item) in arr.enumerated() {
        if item < 0 {
            let _ = arr.remove(at: index)
            arr.insert(item, at: 0)
        } else {
            let _ = arr.remove(at: index)
            arr.insert(item, at: arr.count - 1)
        }
    }
    print(arr)
}

moveNegativeElementToOneSide()


//Sort an array of 0s, 1s and 2s

func sortAnArrayof01Approach2() {
    var arr = [0, 1, 0, 1, 2, 1, 0, 2]
    var zeroIndex = 0, twoIndex = arr.count - 1
    for (index, item) in arr.enumerated() {
        switch item {
        case 0:
            let _ = arr.remove(at: index)
            arr.insert(0, at: zeroIndex)
            zeroIndex += 1
        case 2:
            let _ = arr.remove(at: index)
            arr.insert(2, at: twoIndex)
            twoIndex -= 1
        default:
            break
        }
    }
    print(arr)
}
sortAnArrayof01Approach2()

func sortAnArrayof01Approach1() {
    var arr = [0, 1, 0, 1, 2, 1, 0, 2]
    var zero = 0, one = 0, two = 0
    
    for item in arr {
        switch item {
        case 0:
            zero += 1
        case 1:
            one += 1
        case 2:
            two += 1
        default: break
        }
    }
    for (index, _) in arr.enumerated() {
        if zero > 0 {
            let _ = arr.remove(at: index)
            arr.insert(0, at: index)
            zero -= 1
        } else if one > 0 {
            let _ = arr.remove(at: index)
            arr.insert(1, at: index)
            one -= 1
        } else {
            let _ = arr.remove(at: index)
            arr.insert(2, at: index)
            two -= 1
        }
    }
    
    print(arr)
}

sortAnArrayof01Approach1()

//Find the "Kth" max and min element of an array

func kthSmallestElementOfArray(kthSmallestElementNumber: Int) {
    let arr = [7, 10, 4, 3, 20, 15]
    
    let sortArr = arr.sorted()
    
    print(sortArr[kthSmallestElementNumber - 1])
}

kthSmallestElementOfArray(kthSmallestElementNumber: 2)

//Find the maximum and minimum element in an array

func findMaximumMinimumElement() {
    let arr = [4, 5, 1, 2, 100, 0, 150, 1, 10, 5, 100, 2, 1000, 9, 7, 8, 1]
    var maxElement = arr.first ?? 0
    var minElement = arr.first ?? 0
    
    for item in arr {
        if item < minElement {
            minElement = item
        }
        if item > maxElement {
            maxElement = item
        }
    }
    print("Maximum Element is \(maxElement), & Minimum element is \(minElement)")
}

findMaximumMinimumElement()

//Reverse the array

/*
 
 Input  : arr[] = {1, 2, 3}
 Output : arr[] = {3, 2, 1}

 Input :  arr[] = {4, 5, 1, 2}
 Output : arr[] = {2, 1, 5, 4}
 
 */

func reverseArray() {
//    let arr = [1, 2, 3]
    
    let arr = [4, 5, 1, 2]
    var reversedArray: [Int] = [Int]()
    
    for (index, _) in arr.enumerated() {
        reversedArray.append(arr[arr.count - index - 1])
    }
    
    print(reversedArray)
}

reverseArray()
